/**
 * Created by ngrebenshikov on 29/01/14.
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class solver {
    public static void main(String[] args) throws IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

        HashSet<String> s1 = calculate(in.readLine(), 2);
        HashSet<String> s2 = calculate(in.readLine(), 2);

        for(String s: s1) {
            if(s2.contains(s)) {
                System.out.print("Yes");
                return;
            }
        }
        System.out.print("No");
    }

    private static HashMap<String, Integer> visited = new HashMap<String, Integer>();

    public static HashSet<String> calculate(String s, int level) {
        HashSet<String> result = new HashSet<String>(Collections.singleton(s));
        int len = s.length();
        if (level > 0) {
            for (int l = 0; l < len - 1; l++) {
                for (int r = l+1; r <= len; r++) {
                    StringBuilder sb = new StringBuilder(s.substring(l,r)).reverse();
                    if (l > 0) {
                        sb.insert(0, s.substring(0,l));
                    }
                    if (r < s.length()) {
                        sb.append(s.substring(r));
                    }
                    String cur = sb.toString();
                    result.addAll(calculate(cur, level-1));
                }
            }
        }
        return result;
    }
}
