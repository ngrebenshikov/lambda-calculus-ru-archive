#include <iostream>
#include <cstdio>
#include <set>
#include <string>
#include <algorithm>
#include<tr1/unordered_set>
using namespace std;
using namespace tr1;

unordered_set<string> go(string s, int n){
    unordered_set<string> res;
    res.insert(s);
    
    while(n--){
        unordered_set<string> q;
        for(unordered_set<string>::iterator it=res.begin(); it!=res.end(); it++){
            string z = *it;
            for(int i=0;i<z.length();++i)
            for(int j=i;j<z.length();++j){
                string t = z;
                reverse(t.begin()+i, t.begin()+j+1);
                q.insert(t);
            }
        }
        res = q;
    }
    
    return res;
}

int main(){
    //freopen("input.txt","r",stdin);// freopen("output.txt","w",stdout);
    
    string a, b;
    cin>>a>>b;
    
    unordered_set<string> sa = go(a, 2);
    unordered_set<string> sb = go(b, 2);
    
    bool ok=false;
    for(unordered_set<string>::iterator it=sa.begin(); it!=sa.end(); it++)
    if(sb.count(*it)){
        ok=true;
        break;
    }
    
    cout<<(ok ? "Yes" : "No")<<endl;
    
    return 0;
}
