import java.io.*;
import java.util.*;
     
     
public class solver{
    public static void main(String[] args){
        Scanner in;
        PrintWriter out;
        in = new Scanner(System.in);
        out = new PrintWriter(System.out);
        
        String a = in.next(), b = in.next();
        
        HashSet<String> sa = go(a, 2);
        HashSet<String> sb = go(b, 2);
        
        boolean f = false;
        for(String x : sa) if(sb.contains(x)) f = true;
        
        out.println(f ? "Yes" : "No");
        
        out.flush();
        out.close();
    }
    
    static HashSet<String> go(String s, int n){
        if(n==0) return new HashSet<String>(Collections.singleton(s));
      
        HashSet<String> res = new HashSet<>();
      
        for(int i=0;i<s.length();++i)
        for(int j=i;j<s.length();++j){
            char c[] = s.toCharArray();
            for(int k=0;i+k<j-k;++k){
                char t = c[i+k];
                c[i+k] = c[j-k];
                c[j-k] = t;
            }
            res.addAll(go(new String(c), n-1));
        }
        
        return res;
    }
        
       
}
