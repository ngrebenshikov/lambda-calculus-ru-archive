#include <iostream>
#include <cstdio>
#include <set>
#include <string>
#include <algorithm>
using namespace std;

set<string> go(string s, int n){
    set<string> res;
    res.insert(s);
    
    while(n--){
        set<string> q;
        for(set<string>::iterator it=res.begin(); it!=res.end(); it++){
            string z = *it;
            for(int i=0;i<z.length();++i)
            for(int j=i;j<z.length();++j){
                for(int k=0;i+k<j-k;++k) swap(z[i+k], z[j-k]);
                q.insert(z);
                for(int k=0;i+k<j-k;++k) swap(z[i+k], z[j-k]);
            }
        }
        res = q;
    }
    
    return res;
}

int main(){
    //freopen("input.txt","r",stdin);// freopen("output.txt","w",stdout);
    
    string a, b;
    cin>>a>>b;
    
    set<string> sa = go(a, 2);
    set<string> sb = go(b, 2);
    
    bool ok=false;
    for(set<string>::iterator it=sa.begin(); it!=sa.end(); it++)
    if(sb.count(*it)){
        ok=true;
        break;
    }
    
    cout<<(ok ? "Yes" : "No")<<endl;
    
    return 0;
}
