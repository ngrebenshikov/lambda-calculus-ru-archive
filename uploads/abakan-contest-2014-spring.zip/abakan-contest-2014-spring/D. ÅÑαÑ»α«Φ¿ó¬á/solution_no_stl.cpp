#include <iostream>
#include <cstdio>
#include <algorithm>
#include <memory.h>
using namespace std;

const int M = 32;
const int N = M*M*M*M;

char a[M+1], b[M+1];
char *sa[2][N];
char *sb[2][N];
int ma, mb;

bool cmp(char *a, char *b){
    return strcmp(a,b)<0;
}

void go(char *s, int n, char* q[2][N], int &m){
    m = 0;
    for(int i=0; i<n; ++i)
    for(int j=i; j<n; ++j){
        q[0][m] = new char[n+1];
        strcpy(q[0][m], s);
        for(int k=0;i+k<j-k;++k){
            char t = q[0][m][i+k];
            q[0][m][i+k] = q[0][m][j-k];
            q[0][m][j-k] = t;
        }
        ++m;
    }
    
    int mt = m;
    m = 0;
    for(int k=0;k<mt;++k){
        for(int i=0; i<n; ++i)
        for(int j=i; j<n; ++j){
            q[1][m] = new char[n+1];
            strcpy(q[1][m], q[0][k]);
            for(int k=0;i+k<j-k;++k){
                char t = q[1][m][i+k];
                q[1][m][i+k] = q[1][m][j-k];
                q[1][m][j-k] = t;
            }
            ++m;
        }
    }
    
    sort(q[1], q[1]+m, cmp);
}

int main(){
    //freopen("input.txt","r",stdin);// freopen("output.txt","w",stdout);
    
    gets(a);
    gets(b);
    
    go(a, strlen(a), sa, ma);
    go(b, strlen(b), sb, mb);
    
    
    int i = 0, j = 0;
    
    while(i<ma && j<mb){
        int c = strcmp(sa[1][i], sb[1][i]);
        if(!c){
            cout<<"Yes"<<endl;
            return 0;
        }
        if(c<0) ++i; else ++j;
    }
    
    cout<<"No"<<endl;
    
    return 0;
}

