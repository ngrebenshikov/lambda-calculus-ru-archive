#include <iostream>
#include <cstdio>
#include <set>
#include <string>
#include <algorithm>
using namespace std;

typedef long long ll;

const ll X = 277LL, M = 7777774777777777LL;


set<ll> go2(string s){
    set<ll> res;
    for(int l=0;l<s.length();++l)
    for(int r=l;r<s.length();++r){
        reverse(s.begin()+l, s.begin()+r+1);
        for(int i=0;i<s.length();++i)
        for(int j=i;j<s.length();++j){
            reverse(s.begin()+i, s.begin()+j+1);
            ll h = 0;
            for(int k=0;k<s.length();++k) h = (h*X+s[k])%M;
            res.insert(h);
            reverse(s.begin()+i, s.begin()+j+1);
        }
        reverse(s.begin()+l, s.begin()+r+1);
    }
    return res;
}

int main(){
    //freopen("input.txt","r",stdin);// freopen("output.txt","w",stdout);
    
    string a, b;
    cin>>a>>b;
    
    set<ll> sa = go2(a);
    set<ll> sb = go2(b);
    
    bool ok=false;
    for(set<ll>::iterator it=sa.begin(); it!=sa.end(); it++)
    if(sb.count(*it)){
        ok=true;
        break;
    }
    
    cout<<(ok ? "Yes" : "No")<<endl;
    
    return 0;
}
