#include <iostream>
#include <cstdio>
#include <vector>
#include <string>
#include <algorithm>
using namespace std;

string v[300000];
int vn;

int main(){
    //freopen("input.txt","r",stdin);// freopen("output.txt","w",stdout);
    
    string a, b;
    cin>>a>>b;
    
    
    int n = a.length();
    for(int i=0;i<n;++i)
    for(int j=i;j<n;++j){
        reverse(a.begin()+i, a.begin()+j+1);
        for(int l=0;l<n;++l)
        for(int r=l;r<n;++r){
            reverse(a.begin()+l, a.begin()+r+1);
            v[vn++] = a;
            reverse(a.begin()+l, a.begin()+r+1);
        }
        reverse(a.begin()+i, a.begin()+j+1);
    }
    
    stable_sort(v, v+vn);
    
    n = b.length();
    for(int i=0;i<n;++i)
    for(int j=i;j<n;++j){
        reverse(b.begin()+i, b.begin()+j+1);
        for(int l=0;l<n;++l)
        for(int r=l;r<n;++r){
            reverse(b.begin()+l, b.begin()+r+1);
            string* it = lower_bound(v, v+vn, b);
            if(it!=v+vn && *it==b){
                cout<<"Yes"<<endl;
                return 0;
            }
            reverse(b.begin()+l, b.begin()+r+1);
        }
        reverse(b.begin()+i, b.begin()+j+1);
    }
    
    cout<<"No"<<endl;
    
    
    return 0;
}
