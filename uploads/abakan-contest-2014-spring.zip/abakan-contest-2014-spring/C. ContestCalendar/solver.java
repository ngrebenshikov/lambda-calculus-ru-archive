/**
 * Created by ngrebenshikov on 17/02/14.
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

public class solver {
    class Contest implements Comparable<Contest> {
        public String name;
        public Date start;
        public Date finish;

        @Override
        public int compareTo(Contest o) {
            int dateCmp = start.compareTo(o.start);
            if (dateCmp != 0) {
                return dateCmp;
            } else {
                return name.compareTo(o.name);
            }
        }
    }

    private void run() throws IOException, ParseException {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

        DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm");
        Date curDate = dateFormat.parse(in.readLine());

        int n = Integer.parseInt(in.readLine());

        ArrayList<Contest> contests = new ArrayList<Contest>();

        for (int i=0; i < n; i++) {
            Contest c = new Contest();
            c.name = in.readLine();
            c.start = dateFormat.parse(in.readLine());
            c.finish = dateFormat.parse(in.readLine());
            contests.add(c);
        }

        Collections.sort(contests);

        for(Contest c : contests) {
            if (curDate.after(c.finish) || curDate.equals(c.finish)) continue;
            String status = (curDate.before(c.start)) ? "Coming soon" : "Running";
            int cCount = countChar(createAbbreviation(c.name), 'C');
            String type = (cCount <= 0) ? "boring" :
                    ( (cCount == 1) ? "interesting" : "must coding!" );
            System.out.println(status + " " + c.name + " (" + type + ")");
        }
    }

    private int countChar(String s, char c) {
        int len = s.length();
        int result = 0;
        for(int i=0; i < len; i++) {
            if (s.charAt(i) == c) result += 1;
        }
        return result;
    }

    private String createAbbreviation(String s) {
        int len = s.length();
        StringBuilder result = new StringBuilder();

        String[] parts = s.split(" ");


        for(String p : parts) {
            if (p.equals(p.toUpperCase())) {
                result.append(p);
            } else {
                result.append(p.charAt(0));
            }
        }

        return result.toString().toUpperCase();
    }

    public static void main(String[] args) throws IOException, ParseException {
        solver s = new solver();
        s.run();
    }

}