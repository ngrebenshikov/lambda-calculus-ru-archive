import java.io.*;
import java.util.*;
     
     
public class solver{
    public static void main(String[] args){
    	Scanner in;
    	PrintWriter out;
    	in = new Scanner(System.in);
        out = new PrintWriter(System.out);
        
        String nowDate = convert(in.nextLine());
        int n = in.nextInt();
        in.nextLine();
        
        ArrayList<String[]> contests = new ArrayList<String[]>();
        
        for(int i=0; i<n; ++i){
        	String name = in.nextLine();
        	String begin = convert(in.nextLine());
        	String end = convert(in.nextLine());
        	if(nowDate.compareTo(end)<0) contests.add(new String[]{begin, end, name});
        }
        
        Collections.sort(contests, new Comparator<String[]>() {

			@Override
			public int compare(String[] o1, String[] o2) {
				int cmp = o1[0].compareTo(o2[0]);
				if(cmp!=0) return cmp;
				cmp = o1[2].compareTo(o2[2]);
				return cmp;
			}
		});
        
        String types[] = new String[]{"boring", "interesting", "must coding!"};
        
        for(String s[] : contests){
        	out.print(s[0].compareTo(nowDate)>0 ? "Coming soon" : "Running");
        	out.println(" " + s[2] + " (" + types[countOfC(s[2])] + ")");
        }
        
        out.flush();
        out.close();
    }
    
    public static String convert(String date){
    	String d[] = date.split("[.: ]");
    	return d[2] + d[1] + d[0] + d[3] + d[4];
    }
    
    public static int countOfC(String name){
    	String d[] = name.split(" ");
    	String a = "";
    	for(String s : d){
    		if(s.matches("[0-9]*")) continue;
    		if(s.matches("[A-Z]*")) a+=s; else a+=s.toUpperCase().charAt(0);
    	}
    	int count = 0;
    	for(char x : a.toCharArray()) if(x=='C') ++count;
    	return Math.min(count, 2);
    }
}

