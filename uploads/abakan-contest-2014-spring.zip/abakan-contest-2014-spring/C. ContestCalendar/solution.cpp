#include <iostream>
#include <cstdio>
#include <algorithm>
#include <string>
using namespace std;
typedef long long ll;

const int N = 111;
const int L = 55;

ll val(char *s){
    ll D = (s[0]-'0')*10 + (s[1]-'0') - 1;
    ll M = (s[3]-'0')*10 + (s[4]-'0') - 1;
    ll Y = (s[6]-'0')*1000 + (s[7]-'0')*100 + (s[8]-'0')*10 + (s[9]-'0');
    ll h = (s[11]-'0')*10 + (s[12]-'0');
    ll m = (s[14]-'0')*10 + (s[15]-'0');
    
    return m + h*60 + D*24*60 + M*31*24*60 + Y*366*31*24*60;
}

char s[L];
char t[N][L];
pair<ll, string> a[N];

int main(){
    //freopen("input.txt","r",stdin); //freopen("output.txt","w",stdout);
    
    int n, m = 0;
    
    gets(s);
    
    ll now = val(s);
    
    scanf("%d",&n);
    gets(s);
    
    for(int i=0;i<n;++i){
        gets(t[i]);
        gets(s);
        ll ts = val(s);
        gets(s);
        ll tf = val(s);
        if(now<tf) a[m++] = make_pair(ts, t[i]);
    }
    
    sort(a, a+m);
    
    for(int i=0;i<m;++i){
        if(a[i].first>now) cout<<"Coming soon "; else cout<<"Running ";
        
        string z = a[i].second, x;
        z+=' ';
        int c = 0;
        for(int k=0;k<z.length();++k){
            if(z[k]==' '){
                bool allcaps = true;
                for(int j=0;j<x.length();++j) allcaps&=!(x[j]>='a' && x[j]<='z');
                for(int j=0;j<(allcaps ? x.length() : 1);++j) if(x[j]=='c' || x[j]=='C') ++c;
                x = "";
            }else{
                x += z[k];
            }
        }
        
        cout<<z;
        if(c==0) cout<<"(boring)"; else
        if(c==1) cout<<"(interesting)"; else
        cout<<"(must coding!)";
        
        cout<<endl;
    }
    
    return 0;
}

