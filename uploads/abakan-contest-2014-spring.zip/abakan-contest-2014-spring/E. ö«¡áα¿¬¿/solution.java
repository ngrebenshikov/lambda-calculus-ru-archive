import java.io.*;
import java.util.*;
     
     
public class solver{
	static BufferedReader in;
	static PrintWriter out;
    public static void main(String[] args) throws NumberFormatException, IOException{
    	in = new BufferedReader(new InputStreamReader(System.in));
	    out = new PrintWriter(System.out);
    	
	    int n = Integer.parseInt(in.readLine());
	    String str = in.readLine();
	    int d = (int)Math.sqrt(n);

	    boolean b[][] = new boolean[n+d*2][d+1];
	    boolean a[] = new boolean[n];
	    for(int i=0;i<n;++i) a[i] = str.charAt(i)=='1';

	    for(int m=Integer.parseInt(in.readLine());m>0;--m){
	    	str = in.readLine();
	    	if(str.equals("out")){
	    		char s[] = new char[n];
	    		for(int i=0;i<n;++i){
	    			for(int j=1;j<=d;++j){
	    				a[i]^=b[i][j];
	    				b[i+j][j]^=b[i][j];
	    				b[i][j]=false;
	    			}
	    			s[i] = (a[i] ? '1' : '0');
	    		}
	    		out.println(new String(s));
	    	}else{
	    		String sp[] = str.split(" ");
	    		int i = Integer.parseInt(sp[0]) - 1;
	    		int j = Integer.parseInt(sp[1]) - 1;
	    		int k = Integer.parseInt(sp[2]);
	    		if(k>d){
	    			for(int x=i;x<=j;x+=k) a[x]^=true;
	    		}else{
	    			j = i+((j-i)/k)*k;
	    			b[i][k]^=true;
	    			b[j+k][k]^=true;
	    		}
	    	}
	    }
	    
	    
        out.flush();
        out.close();
    }
    
}

