import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Created by ngrebenshikov on 22/01/14.
 */

public class solver {
    public static void main(String[] args) throws IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

        int k = Integer.parseInt(in.readLine());
        int num = 1;
        int l = 1;
        int d = l-1;
        boolean decreaseD = false;
//        int printedNum = 0;
        while(num < k) {
//            if (num > printedNum) {
//                printedNum = num;
//                int ll = l;
//                StringBuffer sb = new StringBuffer();
//                while(ll > 0) {
//                    sb.append("1");
//                    for(int i = 0; i < d; i++) {
//                        sb.append("0");
//                    }
//                    ll -= d + 1;
//                }
//                System.out.println(sb);
//            }

            if (decreaseD) {
                d--;
                decreaseD = false;
                if (d == 0) {
                    num++;
                    continue;
                }
            }

            if (d == 0) {
                l++;
                d = l-1;
                num++;
            } else if (d == l-1) {
                d = (l-2)/2;
                if (d == 0) num++;
            } else if (l % (d+1) == 0) {
                num++;
                decreaseD = true;
            } else {
                d--;
                if (d == 0) num++;
            }
        }

        StringBuffer sb = new StringBuffer();
        while(l > 0) {
            sb.append("1");
            for(int i = 0; i < d; i++) {
                sb.append("0");
            }
            l -= d + 1;
        }
        System.out.println(sb);
    }
}
