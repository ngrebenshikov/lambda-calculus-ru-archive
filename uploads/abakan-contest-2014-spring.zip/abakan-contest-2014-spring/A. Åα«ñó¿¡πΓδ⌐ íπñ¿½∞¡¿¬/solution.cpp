#include <iostream>
#include <cstdio>
using namespace std;


int main(){
    //freopen("input.txt","r",stdin); freopen("output.txt","w",stdout);
    
    int K;
    cin>>K;
    
    int n, m;
    for(n=1; ; ++n){
        m = 0;
        for(int x=1;x*x<=n;++x) if(n%x==0){
            ++m;
            if(x*x!=n) ++m;
        }
        if(m<K) K-=m; else break;
    }
    
    int d;
    for(d=n; d>=1; --d) if(n%d==0){
        --K;
        if(!K) break;
    }
    
    for(int i=0;i<n/d;++i){
        cout<<1;
        for(int j=1;j<d;++j) cout<<0;
    }
    cout<<endl;
    
    
    return 0;
}

