import java.io.*;
import java.util.*;
     
     
public class solver{
    public static void main(String[] args){
    	Scanner in;
    	PrintWriter out;
    	in = new Scanner(System.in);
        out = new PrintWriter(System.out);
        
        int N = in.nextInt();
        int len;
        int divs[];
        for(len=1; ;++len){
        	divs = divs(len);
        	if(divs.length<N) N-=divs.length;
        	else break;
        }
        
        for(int x : divs){
        	--N;
        	if(N==0){
        		String ans = "";
        		for(int i=0;i<len/x;++i){
        			ans+=1;
        			for(int j=0;j<x-1;++j) ans+=0;
        		}
        		out.println(ans);
                break;
        	}
        }
        
        out.flush();
        out.close();
    }
    
    static public int[] divs(int n){
    	TreeSet<Integer> d = new TreeSet<>();
    	for(int x=1;x<=n;++x) if(n%x==0) d.add(x);
    	
    	int m = d.size();
    	int res[] = new int[m];
    	for(int x : d) res[--m] = x;
    	return res;
    }
}

