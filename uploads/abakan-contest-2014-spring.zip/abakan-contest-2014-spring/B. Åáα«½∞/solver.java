/**
 * Created by ngrebenshikov on 31/01/14.
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;

public class solver {
    public static void main(String[] args) throws IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        StringBuilder result = new StringBuilder();
        int n = Integer.parseInt(in.readLine());
        int cur = 9;
        for (int i=0; i < n - 1; i++) {
            result.append(cur);
            cur--;
        }
        if (cur == 1) {
            result.deleteCharAt(result.length()-1);
            result.append("12");
        } else {
            if (cur % 2 != 0) cur -= 1;
            result.append(cur);
        }
        System.out.println(result.toString());
    }

}
