#include <iostream>
#include <cstdio>
using namespace std;

int c[10];

int main(){
    //freopen("input.txt","r",stdin);// freopen("output.txt","w",stdout);
    
    int n;
    cin>>n;
    
    int t = 1;
    for(int i=0;i<n;++i) t*=10;
    
    for(t-=2;;t-=2){
        bool ok=true;
        for(int x=t; ok && x; x/=10){
            int r=x%10;
            if(!r || c[r]==t) ok=false;
            c[r]=t;
        }
        if(ok) break;
    }
    
    cout<<t<<endl;
    
    return 0;
}

