#include <iostream>
#include <cstdio>
using namespace std;


int main(){
    //freopen("input.txt","r",stdin);// freopen("output.txt","w",stdout);
    
    int a[] = {0,8,98,986,9876,98764,987654,9876542,98765432,987654312};
    int n;
    cin>>n;
    cout<<a[n]<<endl;
    
    return 0;
}