import java.io.*;
import java.util.*;
     
     
public class solver{
	static Scanner in;
	static PrintWriter out;
    public static void main(String[] args){
        out = new PrintWriter(System.out);
		in = new Scanner(System.in);
		
        long a = in.nextLong();
        int n = in.nextInt();
        String s = Long.toBinaryString(a);
        int bits = 0;
        for(int i=0;i<s.length();++i) if(s.charAt(i)=='1') ++bits;
        long count = (1l<<bits)-1;
        
        if(count<n){
        	out.println(-1);
        }else{
        	for(int i=1;i<=n;++i){
        		String t = Long.toBinaryString(count-i);
        		while(t.length()<bits) t = "0"+t;
        		String res = "";
        		for(int j=0, k=0; j<s.length(); ++j){
        			if(s.charAt(j)=='1'){
        				res+=t.charAt(k);
        				++k;
        			}else res+='0';
        		}
        		out.print(Long.parseLong(res, 2)+" ");
        	}
        	out.println();
        }
        
        
        out.flush();
        out.close();
    }
    
}

