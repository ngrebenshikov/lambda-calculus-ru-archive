/**
 * Created by ngrebenshikov on 18/02/14.
 */
import sun.swing.StringUIClientPropertyKey;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.util.Arrays;


public class solver {
    public static void main(String[] args) throws IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

        String[] parts = in.readLine().split(" ");
        BigInteger A = new BigInteger(parts[0], 10);
        int N = Integer.parseInt(parts[1]);

        String binaryA = A.toString(2);

        int k = 0;
        StringBuilder result = new StringBuilder();
        BigInteger mask = calculateFirstMask(binaryA);
        int maskLength = mask.bitLength();

        while (mask.signum() >= 0 && k < N) {
            BigInteger r = new BigInteger(hideOnesByMask(binaryA, createString(maskLength - mask.bitLength(), '0') + mask.toString(2)), 2);
            result.append(r.toString(10) + " ");
            mask = mask.subtract(BigInteger.ONE);
            k += 1;
        }

        if (k == N) {
            System.out.println(result.toString());
        } else {
            System.out.println("-1");
        }
    }

    private static int countOnes(String s) {
        int l = s.length();
        int result = 0;
        for(int i=0; i < l; i++) {
            if (s.charAt(i) == '1') {
                result += 1;
            }
        }
        return result;
    }

    private static String hideOnesByMask(String s, String mask) {
        StringBuilder result = new StringBuilder();
        int l = s.length();
        int k = 0;
        for(int i=0; i < l; i++) {
            if (s.charAt(i) == '1') {
                result.append(mask.charAt(k));
                k += 1;
            } else {
                result.append('0');
            }
        }
        return result.toString();
    }

    private static BigInteger calculateFirstMask(String s) {
        int ones = countOnes(s);
        BigInteger result = new BigInteger("2");
        result = result.pow(ones);
        result = result.subtract(new BigInteger("2"));
        return result;
    }

    public static String createString(int length, char ch) {
        if (length <= 0) return "";
        char[] chars = new char[length];
        Arrays.fill(chars, ch);
        return new String(chars);
    }

}
