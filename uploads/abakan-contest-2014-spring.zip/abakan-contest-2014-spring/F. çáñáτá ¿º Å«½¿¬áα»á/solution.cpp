#include <iostream>
#include <cstdio>
using namespace std;
typedef long long ll;


int main(){
    //freopen("input.txt","r",stdin);// freopen("output.txt","w",stdout);
    
    int n;
    ll a;
    cin>>a>>n;
    
    ll b = 0;
    for(ll t=a; t; t&=t-1) b=b*2+1;
    
    if(b<n) cout<<-1; else
    for(int i=1;i<=n;++i){
        ll x = 0;
        for(ll t=a, c=b-i; t; t&=t-1, c>>=1) if(c&1) x|=t&-t;
        cout<<x<<' ';
    }
    
    return 0;
}

